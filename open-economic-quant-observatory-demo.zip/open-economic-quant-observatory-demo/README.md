# Open Economic & Quant Research Observatory — Demo

A dependency-free, multi-page static demo for the research platform described in the project plan. It is ready to preview locally or deploy directly to GitHub Pages.

## Included pages

- Home and research pulse
- Searchable research library with client-side filters
- Six project detail pages
- Dataset catalog and sortable registry
- Methods library and reproduction interface
- Daily report archive
- About/researcher profile page
- Custom 404 page, favicon, robots file, and sitemap

All numerical research results are **synthetic placeholders for interface demonstration**. Replace them with generated outputs before presenting the site as empirical evidence.

## Local preview

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Deploy to GitHub Pages

1. Create an empty GitHub repository.
2. Copy this folder into the repository root.
3. Commit and push to the `main` branch.
4. In **Settings → Pages**, select **GitHub Actions** as the source.
5. The included `.github/workflows/deploy-pages.yml` publishes the static files.

## Customize

- Replace demo project records in `data/projects.json` and the generated HTML pages.
- Replace placeholder GitHub/Hugging Face actions with real URLs.
- Replace the researcher profile and CV button on `about.html`.
- Replace the placeholder origin in `sitemap.xml` and `robots.txt`.
- Connect newsletter controls to a real provider or RSS feed.
- Generate project pages from `project.yaml` files in the production version.

## Architecture mapping

| Surface | Demo representation |
|---|---|
| GitHub Pages | This static site |
| GitHub Repository | Source, metadata, workflows, tests |
| Hugging Face Dataset | Dataset links and registry placeholders |
| Hugging Face Space | Interactive-demo link placeholders |

## License note

The demo interface code may be adapted for your project. Review licenses and redistribution rights for all research reports and datasets before publication.
