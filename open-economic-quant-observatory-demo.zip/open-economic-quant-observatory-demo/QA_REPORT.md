# Demo QA Report

Validated on August 10, 2026.

## Automated checks

- 13 HTML pages parsed successfully.
- 0 broken local links, stylesheet references, or script references.
- JavaScript syntax check passed with Node.js.
- Project JSON parsed successfully.
- All 13 pages contain exactly one primary `h1`.
- All 13 pages rendered without JavaScript runtime errors in headless Chromium.
- No document-level horizontal overflow at 1280 px or 390 px viewport widths.
- Research search and topic/type filters passed interaction tests.
- Mobile navigation passed interaction tests.
- Dataset-table sorting passed interaction tests.

## Publication warning

All research numbers and findings in this demo are synthetic placeholders. They must be replaced by validated, versioned project outputs before the site is represented as an empirical research product.
